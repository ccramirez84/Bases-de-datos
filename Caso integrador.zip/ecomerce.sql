-- Crear la base de datos ecommerce (si no existe)
CREATE DATABASE IF NOT EXISTS ecommerce;

-- Usar la base de datos ecommerce
USE ecommerce;

-- Tabla clientes
CREATE TABLE clientes (
    idCliente INT PRIMARY KEY,
    nombreCliente VARCHAR(45),
    email VARCHAR(45),
    celular VARCHAR(45),
    direccion VARCHAR(45)
);

-- Tabla metodosPago
CREATE TABLE metodosPago (
    idMetodoPago INT PRIMARY KEY,
    nombreMetodoPago VARCHAR(45)
);

-- Tabla categorias
CREATE TABLE categorias (
    idCategoria INT PRIMARY KEY,
    nombreCategoria VARCHAR(45)
);

-- Tabla productos
CREATE TABLE productos (
    idProducto INT PRIMARY KEY,
    nombreProducto VARCHAR(45),
    descripcion VARCHAR(45),
    precio INT,
    stock INT,
    categorias_idCategoria INT,
    FOREIGN KEY (categorias_idCategoria) REFERENCES categorias(idCategoria)
);

-- Tabla pedidos
CREATE TABLE pedidos (
    idPedido INT PRIMARY KEY AUTO_INCREMENT,
    fechaPedido DATE,
    estadoPedido TINYINT,
    clientes_idCliente INT,
    FOREIGN KEY (clientes_idCliente) REFERENCES clientes(idCliente)
);

-- Tabla pagos
CREATE TABLE pagos (
    idPago INT PRIMARY KEY,
    fechPago DATE,
    montoTotal INT,
    metodosPago_idMetodoPago INT,
    pedidos_idPedido INT,
    pedidos_clientes_idCliente INT,
    FOREIGN KEY (metodosPago_idMetodoPago) REFERENCES metodosPago(idMetodoPago),
    FOREIGN KEY (pedidos_idPedido) REFERENCES pedidos(idPedido),
    FOREIGN KEY (pedidos_clientes_idCliente) REFERENCES clientes(idCliente)
);

-- Tabla detallesPedido
CREATE TABLE detallesPedido (
    idDetallePedido INT PRIMARY KEY AUTO_INCREMENT,
    cantidad INT,
    pedidos_idPedido INT,
    pedidos_clientes_idCliente INT,
    productos_idProducto INT,
    productos_categorias_idCategoria INT,
    FOREIGN KEY (pedidos_idPedido) REFERENCES pedidos(idPedido),
    FOREIGN KEY (pedidos_clientes_idCliente) REFERENCES clientes(idCliente),
    FOREIGN KEY (productos_idProducto) REFERENCES productos(idProducto),
    FOREIGN KEY (productos_categorias_idCategoria) REFERENCES categorias(idCategoria)
);

-- Tabla envios
CREATE TABLE envios (
    idEnvio INT PRIMARY KEY,
    empresaEnvio VARCHAR(45),
    estadoEnvio TINYINT,
    pedidos_idPedido INT,
    pedidos_clientes_idCliente INT,
    FOREIGN KEY (pedidos_idPedido) REFERENCES pedidos(idPedido),
    FOREIGN KEY (pedidos_clientes_idCliente) REFERENCES clientes(idCliente)
);

-- Tabla devoluciones
CREATE TABLE devoluciones (
    idDevolucion INT PRIMARY KEY,
    cantidadDevolucion INT,
    motivoDevolucion VARCHAR(45),
    fechDevolucion DATE,
    pedidos_idPedido INT,
    pedidos_clientes_idCliente INT,
    FOREIGN KEY (pedidos_idPedido) REFERENCES pedidos(idPedido),
    FOREIGN KEY (pedidos_clientes_idCliente) REFERENCES clientes(idCliente)
);

-- Tabla reseñas
CREATE TABLE reseñas (
    idReseña INT PRIMARY KEY,
    calificacion INT,
    fechaReseña DATE,
    pedidos_idPedido INT,
    pedidos_clientes_idCliente INT,
    FOREIGN KEY (pedidos_idPedido) REFERENCES pedidos(idPedido),
    FOREIGN KEY (pedidos_clientes_idCliente) REFERENCES clientes(idCliente)
);
-- Tabla clientes
INSERT INTO clientes (idCliente, nombreCliente, email, celular, direccion) VALUES
(1, 'Laura Vargas', 'laura.vargas@tienda.com', '3101234567', 'Cr 10 # 5 - 20'),
(2, 'Pedro Jiménez', 'pedro.jimenez@tienda.com', '3169876543', 'Cl 25 # 12 - 45'),
(3, 'Carolina Ruiz', 'carolina.ruiz@tienda.com', '3225551111', 'Av 3 # 18 - 10'),
(4, 'Javier Torres', 'javier.torres@tienda.com', '3052229999', 'Dg 15 # 8 - 30'),
(5, 'Valentina Díaz', 'valentina.diaz@tienda.com', '3197772222', 'Tr 5 # 22 - 15');

-- Tabla metodosPago
INSERT INTO metodosPago (idMetodoPago, nombreMetodoPago) VALUES
(1, 'Contra Entrega'),
(2, 'PayPal'),
(3, 'Nequi'),
(4, 'Daviplata'),
(5, 'Tarjeta de Crédito VISA');

-- Tabla categorias
INSERT INTO categorias (idCategoria, nombreCategoria) VALUES
(1, 'Electrónicos'),
(2, 'Moda'),
(3, 'Hogar y Decoración'),
(4, 'Deportes y Aire Libre'),
(5, 'Libros y Música');

-- Tabla productos
INSERT INTO productos (idProducto, nombreProducto, descripcion, precio, stock, categorias_idCategoria) VALUES
(1, 'Smartwatch Deportivo', 'Reloj inteligente con GPS', 250000, 25, 1),
(2, 'Camiseta Estampada', 'Camiseta de algodón con diseño moderno', 45000, 60, 2),
(3, 'Lámpara de Mesa LED', 'Lámpara con luz cálida regulable', 80000, 30, 3),
(4, 'Bicicleta Montañera', 'Bicicleta de montaña con 21 velocidades', 450000, 15, 4),
(5, 'Novela de Ciencia Ficción', 'Libro de ciencia ficción bestseller', 35000, 40, 5);

-- Tabla pedidos
INSERT INTO pedidos (fechaPedido, estadoPedido, clientes_idCliente) VALUES
('2025-04-28', 1, 1),
('2025-04-27', 2, 3),
('2025-04-26', 1, 2),
('2025-04-25', 3, 5),
('2025-04-24', 1, 4);

-- Tabla pagos
INSERT INTO pagos (idPago, fechPago, montoTotal, metodosPago_idMetodoPago, pedidos_idPedido, pedidos_clientes_idCliente) VALUES
(1, '2025-04-28', 250000, 2, 1, 1),
(2, '2025-04-27', 90000, 3, 2, 3),
(3, '2025-04-26', 80000, 1, 3, 2),
(4, '2025-04-25', 450000, 4, 4, 5),
(5, '2025-04-24', 35000, 5, 5, 4);

-- Tabla detallesPedido
INSERT INTO detallesPedido (cantidad, pedidos_idPedido, pedidos_clientes_idCliente, productos_idProducto, productos_categorias_idCategoria) VALUES
(1, 1, 1, 1, 1),
(2, 2, 3, 2, 2),
(1, 3, 2, 3, 3),
(1, 4, 5, 4, 4),
(1, 5, 4, 5, 5);

-- Tabla envios
INSERT INTO envios (idEnvio, empresaEnvio, estadoEnvio, pedidos_idPedido, pedidos_clientes_idCliente) VALUES
(1, 'Envíos Rápidos S.A.S', 1, 1, 1),
(2, 'Logística Express', 2, 2, 3),
(3, 'Servicio al Cliente Ya', 1, 3, 2),
(4, 'Entrega Segura', 3, 4, 5),
(5, 'Tu Paquete a Tiempo', 1, 5, 4);

-- Tabla devoluciones
INSERT INTO devoluciones (idDevolucion, cantidadDevolucion, motivoDevolucion, fechDevolucion, pedidos_idPedido, pedidos_clientes_idCliente) VALUES
(1, 1, 'No era el producto esperado', '2025-04-29', 1, 1),
(2, 1, 'Talla incorrecta', '2025-04-28', 2, 3),
(3, 1, 'Producto dañado durante el envío', '2025-04-30', 3, 2),
(4, 1, 'Color diferente al solicitado', '2025-05-01', 4, 5),
(5, 1, 'Pedido duplicado', '2025-05-02', 5, 4);

-- Tabla reseñas
INSERT INTO reseñas (idReseña, calificacion, fechaReseña, pedidos_idPedido, pedidos_clientes_idCliente) VALUES
(1, 5, '2025-04-29', 1, 1),
(2, 4, '2025-04-28', 2, 3),
(3, 3, '2025-04-30', 3, 2),
(4, 5, '2025-05-01', 4, 5),
(5, 4, '2025-05-02', 5, 4);

-- Insertar un nuevo pedido
DELIMITER //
CREATE PROCEDURE insertar_pedido(IN p_fechaPedido DATE, IN p_estadoPedido TINYINT, IN p_clientes_idCliente INT)
BEGIN
    INSERT INTO pedidos (fechaPedido, estadoPedido, clientes_idCliente)
    VALUES (p_fechaPedido, p_estadoPedido, p_clientes_idCliente);
END //
DELIMITER ;

-- Leer un pedido por su ID
DELIMITER //
CREATE PROCEDURE leer_pedido(IN p_idPedido INT)
BEGIN
    SELECT * FROM pedidos WHERE idPedido = p_idPedido;
END //
DELIMITER ;

-- Actualizar un pedido existente
DELIMITER //
CREATE PROCEDURE actualizar_pedido(IN p_idPedido INT, IN p_fechaPedido DATE, IN p_estadoPedido TINYINT, IN p_clientes_idCliente INT)
BEGIN
    UPDATE pedidos
    SET fechaPedido = p_fechaPedido,
        estadoPedido = p_estadoPedido,
        clientes_idCliente = p_clientes_idCliente
    WHERE idPedido = p_idPedido;
END //
DELIMITER ;

-- Borrar un pedido por su ID
DELIMITER //
CREATE PROCEDURE borrar_pedido(IN p_idPedido INT)
BEGIN
    DELETE FROM pedidos WHERE idPedido = p_idPedido;
END //
DELIMITER ;